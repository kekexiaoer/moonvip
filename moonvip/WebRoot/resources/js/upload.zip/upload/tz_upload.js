/*main*/eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('17 14;17 25;11(14==1p){14=12(13){7.5m(13)}}14.18.5m=12(40){1E{7.4e={};7.13={};7.33=[];7.1A="7D"+14.5O++;7.1k=1c;14.2R[7.1A]=7;7.5F(40);7.5l();11(7.5h()){7.5k()}7.5T()}1F(1Q){3h 14.2R[7.1A];31 1Q}};14.2R={};14.5O=0;14.3Z="2.5.0 7t-6z-15 6M 2";14.6J={7p:-4U,7m:-4N,aF:-53,8H:-4C};14.aH={bi:-b5,94:-9I,9R:-aD,9r:-9V,98:-7i,6n:-6O,84:-7W,7U:-7N,7P:-7V,83:-7v,8D:-6Q};14.6x={99:-1,93:-2,9b:-3,8Q:-4,8X:-5};14.9P={9q:-1,9x:-2};14.5w={9A:-4U,5v:-4N,9w:-53,91:-4C,9k:-4C};14.5u={5x:-1,97:-2};14.5y={5B:"1K",b8:"aX",aY:"bo"};14.bm={aq:-1,a9:-2};14.4k=12(1M){1E{17 3W="",3k=-1;11(19 1M!=="34"||1M.2E(/^aL?:\\/\\//i)||1M.2E(/^\\//)||1M===""){1a 1M}3k=1K.3e.4M.aN("/");11(3k<=0){3W="/"}1d{3W=1K.3e.4M.aA(0,3k)+"/"}1a 3W+1M}1F(1Q){1a 1M}};14.24=12(){};14.18.5F=12(40){7.1b=12(3G,5N){17 4d=40[3G];11(4d!=1p){7.13[3G]=4d}1d{7.13[3G]=5N}};7.1b("2j","");7.1b("5s",1i);7.1b("2L","6D");7.1b("23",{});7.1b("2K",1i);7.1b("2M",1i);7.1b("2N",[]);7.1b("2O",0);7.1b("2T","*.*");7.1b("2U","8g 8m");7.1b("2V",0);7.1b("2Q",0);7.1b("2P",0);7.1b("2h","5D.5p");7.1b("2f","8u.5p");7.1b("3I",1o);7.1b("2q","");7.1b("2A",1);7.1b("2B",1);7.1b("2W","");7.1b("35","80: #81; 9c-7S: 7T;");7.1b("2X",0);7.1b("36",0);7.1b("38",14.5w.5v);7.1b("37",1i);7.1b("3J","");7.1b("3K",1c);7.1b("39",14.5u.5x);7.1b("5Q",14.5y.5B);7.1b("1P",1i);7.13.4c=7.13.1P;7.13.4S=7.4P;7.1b("2w",1c);7.1b("2d",1c);7.1b("3y",1c);7.1b("3w",1c);7.1b("3E",1c);7.1b("3t",1c);7.1b("57",1c);7.1b("3x",1c);7.1b("2a",1c);7.1b("3C",1c);7.1b("3B",1c);7.1b("3p",1c);7.1b("3j",1c);7.1b("3s",1c);7.1b("3v",1c);7.1b("3u",1c);7.1b("3f",7.64);7.1b("3T",{});7.4e=7.13.3T;11(!!7.13.3I){7.13.2h=7.13.2h+(7.13.2h.3X("?")<0?"?":"&")+"5A="+48 5z().5t();7.13.2f=7.13.2f+(7.13.2f.3X("?")<0?"?":"&")+"5A="+48 5z().5t()}11(!7.13.5s){7.13.2j=14.4k(7.13.2j);7.13.2q=14.4k(7.13.2q)}3h 7.1b};14.18.5l=12(){7.1J={2g:25.4r("9.0.28"),42:25.4r("10.0.0")}};14.18.5k=12(){17 27,2S,4l,4m,2r;11(!7.1J.2g){7.1m("2d",["2l 5b 7Y\'t 1J 14"]);1a}11(1T.2y(7.1A)!==1c){7.1J.2g=1i;7.1m("2d",["7Z 7M 7L 1z 7z"]);1a}27=1T.2y(7.13.3J)||7.13.3K;11(27==1p){7.1J.2g=1i;7.1m("2d",["7A 7B 7y 4q 4t"]);1a}4l=(27.5n&&27.5n["2z"]||1K.5o&&1T.7u.5o(27,1c).7w("2z"))!=="5V"?"6g":"3A";2S=1T.2I(4l);4m=7.5C();1E{2S.4D=4m}1F(1Q){7.1J.2g=1i;7.1m("2d",["4b 2g 2l 7J 7K 7I"]);1a}2r=2S.1V("1X");11(!2r||2r.1y>1||2r.1y===0){7.1J.2g=1i;7.1m("2d",["7H 5r 5R 1O 7E 7F 5r 7G"]);1a}1d 11(2r.1y===1){7.1k=2r[0]}27.1G.3c(2S.85,27);11(1K[7.1A]==1p){1K[7.1A]=7.3b()}};14.18.5C=12(8w){1a[\'<1X 1B="\',7.1A,\'" 3P="67/x-66-3a" 3d="\',7.1J.42?7.13.2h:7.13.2f,\'" 1u="\',7.13.2A,\'" 1t="\',7.13.2B,\'" 2H="5D">\',\'<2c 1h="8s" 1w="\',7.13.5Q,\'" />\',\'<2c 1h="1O" 1w="\',7.1J.42?7.13.2h:7.13.2f,\'" />\',\'<2c 1h="30" 1w="8q" />\',\'<2c 1h="8r" 1w="8x" />\',\'<2c 1h="2k" 1w="\'+7.5P()+\'" />\',"</1X>"].2b("")};14.18.5P=12(){17 4n,4j;4j=7.5S();4n=7.13.2N.2b(",");1a["1A=",1j(7.1A),"&1l;8E=",1j(7.13.2j),"&1l;3l=",1j(7.13.2K),"&1l;3g=",1j(7.13.2M),"&1l;8F=",1j(4n),"&1l;8C=",1j(7.13.2O),"&1l;8z=",1j(4j),"&1l;3o=",1j(7.13.2L),"&1l;8B=",1j(7.13.2T),"&1l;8o=",1j(7.13.2U),"&1l;3q=",1j(7.13.2V),"&1l;3m=",1j(7.13.2Q),"&1l;3n=",1j(7.13.2P),"&1l;3i=",1j(7.13.4c),"&1l;2v=",1j(7.13.2q),"&1l;8n=",1j(7.13.2A),"&1l;8b=",1j(7.13.2B),"&1l;8c=",1j(7.13.2W),"&1l;8d=",1j(7.13.2X),"&1l;8a=",1j(7.13.36),"&1l;89=",1j(7.13.35),"&1l;3r=",1j(7.13.38),"&1l;86=",1j(7.13.37),"&1l;87=",1j(7.13.39)].2b("")};14.18.3b=12(){11(7.1k==1p){7.1k=1T.2y(7.1A)}11(7.1k===1c){31"88 4q 5R 2l 8f"}1a 7.1k};14.18.5S=12(){17 1h,2C,4i=[];2C=7.13.23;11(19 2C==="1X"){1n(1h 1z 2C){11(2C.46(1h)){4i.44(1j(1h.1g())+"="+1j(2C[1h].1g()))}}}1a 4i.2b("&1l;")};14.18.8j=12(){17 1k;1E{7.5f(1c,1i);1k=7.4u();11(1k){1E{1k.1G.2s(1k)}1F(1Q){}}1K[7.1A]=1c;14.2R[7.1A]=1c;3h 14.2R[7.1A];7.1k=1c;7.13=1c;7.4e=1c;7.33=1c;7.1A=1c;1a 1o}1F(8h){1a 1i}};14.18.5T=12(){7.1P(["---14 8i 8G---\\n","7d: ",14.3Z,"\\n","6E 6F: ",7.1A,"\\n","6C:\\n","	","2j:               ",7.13.2j,"\\n","	","2h:                ",7.13.2h,"\\n","	","2f:                ",7.13.2f,"\\n","	","2K:         ",7.13.2K.1g(),"\\n","	","2M:         ",7.13.2M.1g(),"\\n","	","2N:             ",7.13.2N.2b(", "),"\\n","	","2O:   ",7.13.2O,"\\n","	","2L:           ",7.13.2L,"\\n","	","23:              ",7.13.23.1g(),"\\n","	","2T:               ",7.13.2T,"\\n","	","2U:   ",7.13.2U,"\\n","	","2V:          ",7.13.2V,"\\n","	","2Q:        ",7.13.2Q,"\\n","	","2P:         ",7.13.2P,"\\n","	","1P:                    ",7.13.1P.1g(),"\\n","	","3I:      ",7.13.3I.1g(),"\\n","	","3J:    ",7.13.3J.1g(),"\\n","	","3K:       ",7.13.3K?"5G":"6I 5G","\\n","	","2q:         ",7.13.2q.1g(),"\\n","	","2A:             ",7.13.2A.1g(),"\\n","	","2B:            ",7.13.2B.1g(),"\\n","	","2W:              ",7.13.2W.1g(),"\\n","	","35:        ",7.13.35.1g(),"\\n","	","2X:  ",7.13.2X.1g(),"\\n","	","36: ",7.13.36.1g(),"\\n","	","38:            ",7.13.38.1g(),"\\n","	","39:            ",7.13.39.1g(),"\\n","	","37:          ",7.13.37.1g(),"\\n","	","3T:          ",7.13.3T.1g(),"\\n","4Q 6N:\\n","	","2w 1x:  ",(19 7.13.2w==="12").1g(),"\\n","	","2d 1x:  ",(19 7.13.2d==="12").1g(),"\\n","	","3y 1x:  ",(19 7.13.3y==="12").1g(),"\\n","	","3s 1x:       ",(19 7.13.3s==="12").1g(),"\\n","	","3u 1x:        ",(19 7.13.3u==="12").1g(),"\\n","	","3v 1x:         ",(19 7.13.3v==="12").1g(),"\\n","	","3w 1x: ",(19 7.13.3w==="12").1g(),"\\n","	","3E 1x:       ",(19 7.13.3E==="12").1g(),"\\n","	","3t 1x:  ",(19 7.13.3t==="12").1g(),"\\n","	","3x 1x:      ",(19 7.13.3x==="12").1g(),"\\n","	","2a 1x:      ",(19 7.13.2a==="12").1g(),"\\n","	","3C 1x:   ",(19 7.13.3C==="12").1g(),"\\n","	","3B 1x:      ",(19 7.13.3B==="12").1g(),"\\n","	","3p 1x:    ",(19 7.13.3p==="12").1g(),"\\n","	","3j 1x:   ",(19 7.13.3j==="12").1g(),"\\n","	","3f 1x:             ",(19 7.13.3f==="12").1g(),"\\n","6y:\\n","	","6L:                     ",7.1J.2g?"5E":"5H","\\n","	","6w 6l:             ",7.1J.42?"5E":"5H","\\n"].2b(""))};14.18.6i=12(1h,1w,5I){11(1w==1p){1a 7.13[1h]=5I}1d{1a 7.13[1h]=1w}};14.18.6v=12(1h){11(7.13[1h]!=1p){1a 7.13[1h]}1a""};14.18.1f=12(4g,1N){17 1k,1q,4f;1N=1N||[];1k=7.3b();1E{11(1k!=1p){4f=1k.5a(\'<5L 1h="\'+4g+\'" 6p="6u">\'+6t(1N,0)+"</5L>");1q=6r(4f)}1d{7.1P("6K\'t 3N 3a 7s 5g 1O 7g\'t 4t.")}}1F(1Q){7.1P("4b 6R 3a 12 \'"+4g+"\': "+1Q.1r)}11(1q!=1p&&19 1q.2Z==="1X"){1q=7.1L(1q)}1a 1q};14.18.7e=12(){7.1f("7b")};14.18.7c=12(){7.1f("7j")};14.18.7k=12(1s){7.1f("5W",[1s])};14.18.7q=12(1s,1u,1t,3D,30,4h){7.1f("5W",[1s,{1u:1u,1t:1t,3D:3D,30:30,4h:4h}])};14.18.5f=12(1s,3U){11(3U!==1i){3U=1o}7.1f("7l",[1s,3U])};14.18.7n=12(){7.1f("7a")};14.18.79=12(4W){1a 7.1f("6X",[4W])};14.18.6Z=12(){1a 7.1f("6W")};14.18.6V=12(4V){7.1f("6S",[4V])};14.18.6U=12(1s){11(19 1s==="4X"){1a 7.1f("70",[1s])}1d{1a 7.1f("4Y",[1s])}};14.18.71=12(1s){11(19 1s==="4X"){1a 7.1f("78",[1s])}1d{1a 7.1f("4Y",[1s])}};14.18.73=12(1s,1h,1w){1a 7.1f("7h",[1s,1h,1w])};14.18.74=12(1s,1h){7.1f("72",[1s,1h])};14.18.7f=12(1M){7.13.2j=1M.1g();7.1f("6A",[1M])};14.18.6G=12(4o){7.13.23=4o;7.1f("4p",[4o])};14.18.9Y=12(1h,1w){7.13.23[1h]=1w;7.1f("4p",[7.13.23])};14.18.aE=12(1h){3h 7.13.23[1h];7.1f("4p",[7.13.23])};14.18.aC=12(4x,3M){7.13.2T=4x;7.13.2U=3M;7.1f("aB",[4x,3M])};14.18.aI=12(3q){7.13.2V=3q;7.1f("aO",[3q])};14.18.aQ=12(3m){7.13.2Q=3m;7.1f("aM",[3m])};14.18.aK=12(3n){7.13.2P=3n;7.1f("ay",[3n])};14.18.a6=12(3o){7.13.2L=3o;7.1f("a8",[3o])};14.18.a4=12(3l){7.13.2K=3l;7.1f("a1",[3l])};14.18.a3=12(3g){7.13.2M=3g;7.1f("ao",[3g])};14.18.av=12(2x){11(19 2x==="34"){2x=2x.29(" ","").20(",")}7.13.2N=2x;7.1f("at",[2x])};14.18.ap=12(4y){7.13.2O=4y;7.1f("ar",[4y])};14.18.aS=12(3i){7.13.4c=3i;7.1f("bj",[3i])};14.18.bh=12(2v){11(2v==1p){2v=""}7.13.2q=2v;7.1f("bc",[2v])};14.18.bf=12(1u,1t){7.13.2A=1u;7.13.2B=1t;17 1O=7.3b();11(1O!=1p){1O.1I.1u=1u+"4O";1O.1I.1t=1t+"4O"}7.1f("bq",[1u,1t])};14.18.bn=12(4A){7.13.2W=4A;7.1f("bt",[4A])};14.18.bl=12(3O,3Q){7.13.2X=3Q;7.13.36=3O;7.1f("aZ",[3O,3Q])};14.18.b0=12(3R){7.13.35=3R;7.1f("aW",[3R])};14.18.aT=12(4w){7.13.37=4w;7.1f("aV",[4w])};14.18.b2=12(3r){7.13.38=3r;7.1f("b9",[3r])};14.18.b6=12(4v){7.13.39=4v;7.1f("b4",[4v])};14.18.1m=12(2J,1N){17 4R=7;11(1N==1p){1N=[]}1d 11(!(1N ba 9Z)){1N=[1N]}11(19 7.13[2J]==="12"){7.33.44(12(){7.13[2J].5c(7,1N)});2i(12(){4R.5d()},0)}1d 11(7.13[2J]!==1c){31"4Q 96 "+2J+" 52 55 92 52 4q a 12"}};14.18.5d=12(){17 f=7.33?7.33.9i():1c;11(19 f==="12"){f.5c(7)}};14.18.1L=12(1e){17 5e=/[$]([0-9a-f]{4})/i,4s={},2D,k,2E;11(1e!=1p){1n(k 1z 1e.2Z){11(1e.2Z.46(k)){2D=k;9h((2E=5e.5j(2D))!==1c){2D=2D.29(2E[0],9g.9d(1D("9e"+2E[1],16)))}4s[2D]=1e.2Z[k]}}1e.2Z=4s}1a 1e};14.18.5h=12(){17 1q;11(19 7.13.2w==="12"){1q=7.13.2w.3N(7)}1d 11(7.13.2w!=1p){31"2a 4Z be a 12"}11(1q===1p){1q=1o}1a!!1q};14.18.8M=12(){17 1k=7.4u();11(!1k){7.1P("2l 8L 8I 8J 8K 5g 3a 1O 8R\'t be 4t.");1a}7.1m("3y")};14.18.4u=12(){17 22,1k=7.3b();1E{11(1k&&19 1k.5a==="55"){7.1P("8V 2l 8S 8T (7 54 8U 9l 1z 9m 9M 54 9N 9O 9L)");1n(22 1z 1k){1E{11(19 1k[22]==="12"){1k[22]=1c}}1F(1Q){}}}}1F(9K){}1K["9H"]=12(4B,1h){1E{11(4B){4B[1h]=1c}}1F(9J){}};1a 1k};14.18.9Q=12(){7.1m("3s")};14.18.9X=12(){7.1m("3u")};14.18.9U=12(){7.1m("3v")};14.18.9S=12(){7.1m("3w")};14.18.9G=12(1e){1e=7.1L(1e);7.1m("3E",1e)};14.18.9s=12(1e,3z,1r){1e=7.1L(1e);7.1m("3t",[1e,3z,1r])};14.18.9u=12(59,58,5i){7.1m("57",[59,58,5i])};14.18.9o=12(1e,2Y){1e=7.1L(1e);7.1m("3x",[1e,2Y.1u,2Y.1t,2Y.3D,2Y.30])};14.18.9C=12(1e){1e=7.1L(1e);7.1m("4S",1e)};14.18.4P=12(1e){17 1q;11(19 7.13.2a==="12"){1e=7.1L(1e);1q=7.13.2a.3N(7,1e)}1d 11(7.13.2a!=1p){31"2a 4Z be a 12"}11(1q===1p){1q=1o}1q=!!1q;7.1f("9y",[1q])};14.18.9z=12(1e,5J,6e){1e=7.1L(1e);7.1m("3C",[1e,5J,6e])};14.18.9B=12(1e,3z,1r){1e=7.1L(1e);7.1m("3B",[1e,3z,1r])};14.18.9D=12(1e,6b,61){1e=7.1L(1e);7.1m("3p",[1e,6b,61])};14.18.9n=12(1e){1e=7.1L(1e);7.1m("3j",1e)};14.18.1P=12(1r){7.1m("3f",1r)};14.18.64=12(1r){17 32,2u,22;11(7.13.1P){2u=[];11(19 1r==="1X"&&19 1r.1h==="34"&&19 1r.1r==="34"){1n(22 1z 1r){11(1r.46(22)){2u.44(22+": "+1r[22])}}32=2u.2b("\\n")||"";2u=32.20("\\n");32="9j: "+2u.2b("\\95: ");14.3F.4a(32)}1d{14.3F.4a(1r)}}};14.3F={};14.3F.4a=12(1r){17 1v,3Y;1E{1v=1T.2y("5Y");11(!1v){3Y=1T.2I("b7");1T.1V("2G")[0].2e(3Y);1v=1T.2I("bs");1v.1B="5Y";1v.1I.az="aG";1v.1U("69","6d");1v.69="6d";1v.1I.75="77";1v.1I.1u="6T";1v.1I.1t="6Y";1v.1I.7o="7r";3Y.2e(1v)}1v.1w+=1r+"\\n";1v.6s=1v.6q-1v.6j}1F(1Q){6k("4b: "+1Q.1h+" 6m: "+1Q.1r)}};25=12(){17 D="1p",r="1X",S="6B 2l",W="68.68",q="67/x-66-3a",R="8l",x="8e",O=1K,j=1T,t=8y,T=1i,U=[h],o=[],N=[],I=[],l,Q,E,B,J=1i,a=1i,n,G,m=1o,M=12(){17 aa=19 j.2y!=D&&19 j.1V!=D&&19 j.2I!=D,ah=t.8p.1Y(),Y=t.8t.1Y(),ae=Y?/1C/.1S(Y):/1C/.1S(ah),ac=Y?/2F/.1S(Y):/2F/.1S(ah),af=/63/.1S(ah)?8v(ah.29(/^.*63\\/(\\d+(\\.\\d+)?).*$/,"$1")):1i,X=!+"1",ag=[0,0,0],ab=1c;11(19 t.43!=D&&19 t.43[S]==r){ab=t.43[S].3M;11(ab&&!(19 t.49!=D&&t.49[q]&&!t.49[q].7X)){T=1o;X=1i;ab=ab.29(/^.*\\s+(\\S+\\s+\\S+$)/,"$1");ag[0]=1D(ab.29(/^(.*)\\..*$/,"$1"),10);ag[1]=1D(ab.29(/^.*\\.(.*)\\s.*$/,"$1"),10);ag[2]=/[a-60-Z]/.1S(ab)?1D(ab.29(/^.*[a-60-Z]+(.*)$/,"$1"),10):0}}1d{11(19 O.62!=D){1E{17 ad=48 62(W);11(ad){ab=ad.4E("$3Z");11(ab){X=1o;ab=ab.20(" ")[1].20(",");ag=[1D(ab[0],10),1D(ab[1],10),1D(ab[2],10)]}}}1F(Z){}}}1a{21:aa,2o:ag,1W:af,1H:X,1C:ae,2F:ac}}(),k=12(){11(!M.21){1a}11(19 j.1R!=D&&j.1R=="4z"||19 j.1R==D&&(j.1V("2G")[0]||j.2G)){f()}11(!J){11(19 j.2t!=D){j.2t("7O",f,1i)}11(M.1H&&M.1C){j.3V(x,12(){11(j.1R=="4z"){j.50(x,2p.2n);f()}});11(O==3Q){(12(){11(J){1a}1E{j.7Q.7R("3O")}1F(X){2i(2p.2n,0);1a}f()})()}}11(M.1W){(12(){11(J){1a}11(!/bk|4z/.1S(j.1R)){2i(2p.2n,0);1a}f()})()}s(f)}}();12 f(){11(J){1a}1E{17 Z=j.1V("2G")[0].2e(C("6g"));Z.1G.2s(Z)}1F(aa){1a}J=1o;17 X=U.1y;1n(17 Y=0;Y<X;Y++){U[Y]()}}12 K(X){11(J){X()}1d{U[U.1y]=X}}12 s(Y){11(19 O.2t!=D){O.2t("6c",Y,1i)}1d{11(19 j.2t!=D){j.2t("6c",Y,1i)}1d{11(19 O.3V!=D){i(O,"24",Y)}1d{11(19 O.24=="12"){17 X=O.24;O.24=12(){X();Y()}}1d{O.24=Y}}}}}12 h(){11(T){V()}1d{H()}}12 V(){17 X=j.1V("2G")[0];17 aa=C(r);aa.1U("3P",q);17 Z=X.2e(aa);11(Z){17 Y=0;(12(){11(19 Z.4E!=D){17 ab=Z.4E("$3Z");11(ab){ab=ab.20(" ")[1].20(",");M.2o=[1D(ab[0],10),1D(ab[1],10),1D(ab[2],10)]}}1d{11(Y<10){Y++;2i(2p.2n,10);1a}}X.2s(aa);Z=1c;H()})()}1d{H()}}12 H(){17 ag=o.1y;11(ag>0){1n(17 af=0;af<ag;af++){17 Y=o[af].1B;17 ab=o[af].6a;17 aa={2m:1i,1B:Y};11(M.2o[0]>0){17 ae=c(Y);11(ae){11(F(o[af].56)&&!(M.1W&&M.1W<3H)){w(Y,1o);11(ab){aa.2m=1o;aa.45=z(Y);ab(aa)}}1d{11(o[af].4L&&A()){17 ai={};ai.3d=o[af].4L;ai.1u=ae.1Z("1u")||"0";ai.1t=ae.1Z("1t")||"0";11(ae.1Z("2H")){ai.4I=ae.1Z("2H")}11(ae.1Z("4K")){ai.4K=ae.1Z("4K")}17 ah={};17 X=ae.1V("2c");17 ac=X.1y;1n(17 ad=0;ad<ac;ad++){11(X[ad].1Z("1h").1Y()!="1O"){ah[X[ad].1Z("1h")]=X[ad].1Z("1w")}}P(ai,ah,Y,ab)}1d{p(ae);11(ab){ab(aa)}}}}}1d{w(Y,1o);11(ab){17 Z=z(Y);11(Z&&19 Z.5Z!=D){aa.2m=1o;aa.45=Z}ab(aa)}}}}}12 z(aa){17 X=1c;17 Y=c(aa);11(Y&&Y.41=="4G"){11(19 Y.5Z!=D){X=Y}1d{17 Z=Y.1V(r)[0];11(Z){X=Z}}}1a X}12 A(){1a!a&&F("6.0.65")&&(M.1C||M.2F)&&!(M.1W&&M.1W<3H)}12 P(aa,ab,X,Z){a=1o;E=Z||1c;B={2m:1i,1B:X};17 ae=c(X);11(ae){11(ae.41=="4G"){l=g(ae);Q=1c}1d{l=ae;Q=X}aa.1B=R;11(19 aa.1u==D||!/%$/.1S(aa.1u)&&1D(aa.1u,10)<6f){aa.1u="6f"}11(19 aa.1t==D||!/%$/.1S(aa.1t)&&1D(aa.1t,10)<6h){aa.1t="6h"}j.4J=j.4J.9E(0,47)+" - 2l 5b 9p";17 ad=M.1H&&M.1C?"9t":"9F",ac="9T="+O.3e.1g().29(/&/g,"%26")+"&8Z="+ad+"&8Y="+j.4J;11(19 ab.2k!=D){ab.2k+="&"+ac}1d{ab.2k=ac}11(M.1H&&M.1C&&ae.1R!=4){17 Y=C("3A");X+="8O";Y.1U("1B",X);ae.1G.51(Y,ae);ae.1I.2z="4F";(12(){11(ae.1R==4){ae.1G.2s(ae)}1d{2i(2p.2n,10)}})()}u(aa,ab,X)}}12 p(Y){11(M.1H&&M.1C&&Y.1R!=4){17 X=C("3A");Y.1G.51(X,Y);X.1G.3c(g(Y),X);Y.1I.2z="4F";(12(){11(Y.1R==4){Y.1G.2s(Y)}1d{2i(2p.2n,10)}})()}1d{Y.1G.3c(g(Y),Y)}}12 g(ab){17 aa=C("3A");11(M.1C&&M.1H){aa.4D=ab.4D}1d{17 Y=ab.1V(r)[0];11(Y){17 ad=Y.b1;11(ad){17 X=ad.1y;1n(17 Z=0;Z<X;Z++){11(!(ad[Z].5X==1&&ad[Z].41=="bp")&&!(ad[Z].5X==8)){aa.2e(ad[Z].aR(1o))}}}}}1a aa}12 u(ai,ag,Y){17 X,aa=c(Y);11(M.1W&&M.1W<3H){1a X}11(aa){11(19 ai.1B==D){ai.1B=Y}11(M.1H&&M.1C){17 ah="";1n(17 ae 1z ai){11(ai[ae]!=3S.18[ae]){11(ae.1Y()=="3d"){ag.1O=ai[ae]}1d{11(ae.1Y()=="4I"){ah+=\' 2H="\'+ai[ae]+\'"\'}1d{11(ae.1Y()!="4H"){ah+=" "+ae+\'="\'+ai[ae]+\'"\'}}}}}17 af="";1n(17 ad 1z ag){11(ag[ad]!=3S.18[ad]){af+=\'<2c 1h="\'+ad+\'" 1w="\'+ag[ad]+\'" />\'}}aa.au=\'<1X 4H="a2:a0-a5-ax-aJ-aP"\'+ah+">"+af+"</1X>";N[N.1y]=ai.1B;X=c(ai.1B)}1d{17 Z=C(r);Z.1U("3P",q);1n(17 ac 1z ai){11(ai[ac]!=3S.18[ac]){11(ac.1Y()=="4I"){Z.1U("2H",ai[ac])}1d{11(ac.1Y()!="4H"){Z.1U(ac,ai[ac])}}}}1n(17 ab 1z ag){11(ag[ab]!=3S.18[ab]&&ab.1Y()!="1O"){e(Z,ab,ag[ab])}}aa.1G.3c(Z,aa);X=Z}}1a X}12 e(Z,X,Y){17 aa=C("2c");aa.1U("1h",X);aa.1U("1w",Y);Z.2e(aa)}12 y(Y){17 X=c(Y);11(X&&X.41=="4G"){11(M.1H&&M.1C){X.1I.2z="4F";(12(){11(X.1R==4){b(Y)}1d{2i(2p.2n,10)}})()}1d{X.1G.2s(X)}}}12 b(Z){17 Y=c(Z);11(Y){1n(17 X 1z Y){11(19 Y[X]=="12"){Y[X]=1c}}Y.1G.2s(Y)}}12 c(Z){17 X=1c;1E{X=j.2y(Z)}1F(Y){}1a X}12 C(X){1a j.2I(X)}12 i(Z,X,Y){Z.3V(X,Y);I[I.1y]=[Z,X,Y]}12 F(Z){17 Y=M.2o,X=Z.20(".");X[0]=1D(X[0],10);X[1]=1D(X[1],10)||0;X[2]=1D(X[2],10)||0;1a Y[0]>X[0]||Y[0]==X[0]&&Y[1]>X[1]||Y[0]==X[0]&&Y[1]==X[1]&&Y[2]>=X[2]?1o:1i}12 v(ac,Y,ad,ab){11(M.1H&&M.2F){1a}17 aa=j.1V("82")[0];11(!aa){1a}17 X=ad&&19 ad=="34"?ad:"bd";11(ab){n=1c;G=1c}11(!n||G!=X){17 Z=C("1I");Z.1U("3P","7C/3R");Z.1U("8A",X);n=aa.2e(Z);11(M.1H&&M.1C&&19 j.3L!=D&&j.3L.1y>0){n=j.3L[j.3L.1y-1]}G=X}11(M.1H&&M.1C){11(n&&19 n.5U==r){n.5U(ac,Y)}}1d{11(n&&19 j.5M!=D){n.2e(j.5M(ac+" {"+Y+"}"))}}}12 w(Z,X){11(!m){1a}17 Y=X?"6H":"6P";11(J&&c(Z)){c(Z).1I.5K=Y}1d{v("#"+Z,"5K:"+Y)}}12 L(Y){17 Z=/[\\\\\\"<>\\.;]/;17 X=Z.5j(Y)!=1c;1a X&&19 1j!=D?1j(Y):Y}17 d=12(){11(M.1H&&M.1C){1K.3V("6o",12(){17 ac=I.1y;1n(17 ab=0;ab<ac;ab++){I[ab][0].50(I[ab][1],I[ab][2])}17 Z=N.1y;1n(17 aa=0;aa<Z;aa++){y(N[aa])}1n(17 Y 1z M){M[Y]=1c}M=1c;1n(17 X 1z 25){25[X]=1c}25=1c})}}();1a{9W:12(ab,X,aa,Z){11(M.21&&ab&&X){17 Y={};Y.1B=ab;Y.56=X;Y.4L=aa;Y.6a=Z;o[o.1y]=Y;w(ab,1i)}1d{11(Z){Z({2m:1i,1B:ab})}}},7x:12(X){11(M.21){1a z(X)}},8k:12(ab,ah,ae,ag,Y,aa,Z,ad,af,ac){17 X={2m:1i,1B:ah};11(M.21&&!(M.1W&&M.1W<3H)&&ab&&ah&&ae&&ag&&Y){w(ah,1i);K(12(){ae+="";ag+="";17 aj={};11(af&&19 af===r){1n(17 al 1z af){aj[al]=af[al]}}aj.3d=ab;aj.1u=ae;aj.1t=ag;17 am={};11(ad&&19 ad===r){1n(17 ak 1z ad){am[ak]=ad[ak]}}11(Z&&19 Z===r){1n(17 ai 1z Z){11(19 am.2k!=D){am.2k+="&"+ai+"="+Z[ai]}1d{am.2k=ai+"="+Z[ai]}}}11(F(Y)){17 an=u(aj,am,ah);11(aj.1B==ah){w(ah,1o)}X.2m=1o;X.45=an}1d{11(aa&&A()){aj.3d=aa;P(aj,am,ah,ac);1a}1d{w(ah,1o)}}11(ac){ac(X)}})}1d{11(ac){ac(X)}}},9v:12(){m=1i},8W:M,8P:12(){1a{8N:M.2o[0],90:M.2o[1],9f:M.2o[2]}},4r:F,b3:12(Z,Y,X){11(M.21){1a u(Z,Y,X)}1d{1a 1p}},aU:12(Z,aa,X,Y){11(M.21&&A()){P(Z,aa,X,Y)}},bb:12(X){11(M.21){y(X)}},br:12(aa,Z,Y,X){11(M.21){v(aa,Z,Y,X)}},5q:K,bg:s,as:12(aa){17 Z=j.3e.aw||j.3e.a7;11(Z){11(/\\?/.1S(Z)){Z=Z.20("?")[1]}11(aa==1c){1a L(Z)}17 Y=Z.20("&");1n(17 X=0;X<Y.1y;X++){11(Y[X].4T(0,Y[X].3X("="))==aa){1a L(Y[X].4T(Y[X].3X("=")+1))}}}1a""},76:12(){11(a){17 X=c(R);11(X&&l){X.1G.3c(l,X);11(Q){w(Q,1o);11(M.1H&&M.1C){l.1I.2z="5V"}}11(E){E(B)}}a=1i}}}}();25.5q(12(){11(19 14.24==="12"){14.24.3N(1K)}});',62,712,'|||||||this||||||||||||||||||||||||||||||||||||||||||||||||||||||||if|function|settings|SWFUpload|||var|prototype|typeof|return|ensureDefault|null|else|file|callFlash|toString|name|false|encodeURIComponent|movieElement|amp|queueEvent|for|true|undefined|returnValue|message|fileID|height|width|console|value|assigned|length|in|movieName|id|win|parseInt|try|catch|parentNode|ie|style|support|window|unescapeFilePostParams|url|argumentArray|movie|debug|ex|readyState|test|document|setAttribute|getElementsByTagName|wk|object|toLowerCase|getAttribute|split|w3|key|post_params|onload|swfobject||targetElement||replace|upload_start_handler|join|param|swfupload_load_failed_handler|appendChild|flash9_url|loading|flash_url|setTimeout|upload_url|flashvars|Flash|success|callee|pv|arguments|button_image_url|els|removeChild|addEventListener|exceptionValues|buttonImageURL|swfupload_preload_handler|http_status_codes|getElementById|display|button_width|button_height|postParams|uk|match|mac|body|class|createElement|handlerName|use_query_string|file_post_name|requeue_on_error|http_success|assume_success_timeout|file_queue_limit|file_upload_limit|instances|tempParent|file_types|file_types_description|file_size_limit|button_text|button_text_top_padding|resizeSettings|post|quality|throw|exceptionMessage|eventQueue|string|button_text_style|button_text_left_padding|button_disabled|button_action|button_cursor|flash|getMovieElement|replaceChild|data|location|debug_handler|requeueOnError|delete|debugEnabled|upload_complete_handler|indexSlash|useQueryString|fileUploadLimit|fileQueueLimit|filePostName|upload_success_handler|fileSizeLimit|buttonAction|mouse_click_handler|file_queue_error_handler|mouse_over_handler|mouse_out_handler|file_dialog_start_handler|upload_resize_start_handler|swfupload_loaded_handler|errorCode|div|upload_error_handler|upload_progress_handler|encoding|file_queued_handler|Console|settingName|312|prevent_swf_caching|button_placeholder_id|button_placeholder|styleSheets|description|call|left|type|top|css|Object|custom_settings|triggerErrorEvent|attachEvent|path|indexOf|documentForm|version|userSettings|nodeName|imageResize|plugins|push|ref|hasOwnProperty||new|mimeTypes|writeLine|Exception|debug_enabled|setting|customSettings|returnString|functionName|allowEnlarging|paramStringPairs|paramString|completeURL|wrapperType|flashHTML|httpSuccessString|paramsObject|SetPostParams|not|hasFlashPlayerVersion|unescapedPost|found|cleanUp|cursor|isDisabled|types|timeout_seconds|complete|html|instance|130|innerHTML|GetVariable|none|OBJECT|classid|styleclass|title|align|expressInstall|pathname|110|px|returnUploadStart|Event|self|return_upload_start_handler|substring|100|statsObject|indexOrFileID|number|GetFile|must|detachEvent|insertBefore|is|120|should|unknown|swfVersion|file_dialog_complete_handler|numFilesQueued|numFilesSelected|CallFunction|Player|apply|executeNextEvent|reg|cancelUpload|the|swfuploadPreload|numFilesInQueue|exec|loadFlash|loadSupport|initSWFUpload|currentStyle|getComputedStyle|swf|addDomLoadEvent|to|preserve_relative_urls|getTime|CURSOR|SELECT_FILES|BUTTON_ACTION|ARROW|WINDOW_MODE|Date|preventswfcaching|WINDOW|getFlashHTML|swfupload|Yes|initSettings|Set|No|default_value|bytesComplete|visibility|invoke|createTextNode|defaultValue|movieCount|getFlashVars|button_window_mode|find|buildParamString|displayDebugInfo|addRule|block|StartUpload|nodeType|SWFUpload_Console|SetVariable|zA|responseReceived|ActiveXObject|webkit|debugMessage||shockwave|application|ShockwaveFlash|wrap|callbackFn|serverData|load|off|bytesTotal|310|span|137|addSetting|clientHeight|alert|Resize|Message|UPLOAD_FAILED|onunload|returntype|scrollHeight|eval|scrollTop|__flash__argumentsToXML|javascript|getSetting|Image|FILE_STATUS|Support|01|SetUploadURL|Shockwave|Settings|Filedata|Movie|Name|setPostParams|visible|Not|QUEUE_ERROR|Can|Load|Beta|Handlers|250|hidden|300|calling|SetStats|700px|getFile|setStats|GetStats|RequeueUpload|350px|getStats|GetFileByIndex|getQueueFile|RemoveFileParam|addFileParam|removeFileParam|overflow|expressInstallCallback|auto|GetFileByQueueIndex|requeueUpload|StopUpload|SelectFile|selectFiles|Version|selectFile|setUploadURL|wasn|AddFileParam|240|SelectFiles|startUpload|CancelUpload|FILE_EXCEEDS_SIZE_LIMIT|stopUpload|margin|QUEUE_LIMIT_EXCEEDED|startResizedUpload|5px|because|2010|defaultView|290|getPropertyValue|getObjectById|holder|use|button|place|text|SWFUpload_|after|adding|DOM|Unable|placeholder|HTML|into|already|ID|270|DOMContentLoaded|FILE_CANCELLED|documentElement|doScroll|size|16pt|FILE_VALIDATION_FAILED|280|260|enabledPlugin|doesn|Element|color|000000|head|UPLOAD_STOPPED|SPECIFIED_FILE_ID_NOT_FOUND|firstChild|buttonDisabled|buttonCursor|Could|buttonTextStyle|buttonTextLeftPadding|buttonHeight|buttonText|buttonTextTopPadding|onreadystatechange|element|All|ex2|Instance|destroy|embedSWF|SWFObjectExprInst|Files|buttonWidth|fileTypesDescription|userAgent|high|allowScriptAccess|wmode|platform|swfupload_fp9|parseFloat|flashVersion|always|navigator|params|media|fileTypes|assumeSuccessTimeout|RESIZE|uploadURL|httpSuccess|Info|INVALID_FILETYPE|back|ready|but|called|flashReady|major|SWFObjectNew|getFlashPlayerVersion|COMPLETE|can|functions|hooks|only|Removing|ua|CANCELLED|MMdoctitle|MMplayerType|minor|JAVASCRIPT|or|IN_PROGRESS|MISSING_UPLOAD_URL|nEXCEPTION|handler|HAND|UPLOAD_LIMIT_EXCEEDED|QUEUED||ERROR|font|fromCharCode|0x|release|String|while|shift|EXCEPTION|NONE|run|IE|uploadComplete|uploadResizeStart|Installation|NORMAL|SECURITY_ERROR|fileQueueError|ActiveX|fileDialogComplete|switchOffAutoHideShow|START_UPLOAD|RESIZED|ReturnUploadStart|uploadProgress|SELECT_FILE|uploadError|uploadStart|uploadSuccess|slice|PlugIn|fileQueued|__flash__removeCallback|210|flashEx|ex1|leaks|and|prevent|memory|UPLOAD_TYPE|mouseClick|IO_ERROR|fileDialogStart|MMredirectURL|mouseOut|230|registerObject|mouseOver|addPostParam|Array|D27CDB6E|SetUseQueryString|clsid|setRequeueOnError|setUseQueryString|AE6D|setFilePostName|hash|SetFilePostName|PNG|||||||||||||||SetRequeueOnError|setAssumeSuccessTimeout|JPEG|SetAssumeSuccessTimeout|getQueryParamValue|SetHTTPSuccess|outerHTML|setHTTPSuccess|search|11cf|SetFileQueueLimit|fontFamily|substr|SetFileTypes|setFileTypes|220|removePostParam|ZERO_BYTE_FILE|monospace|UPLOAD_ERROR|setFileSizeLimit|96B8|setFileQueueLimit|https|SetFileUploadLimit|lastIndexOf|SetFileSizeLimit|444553540000|setFileUploadLimit|cloneNode|setDebugEnabled|setButtonDisabled|showExpressInstall|SetButtonDisabled|SetButtonTextStyle|transparent|OPAQUE|SetButtonTextPadding|setButtonTextStyle|childNodes|setButtonAction|createSWF|SetButtonCursor|200|setButtonCursor|form|TRANSPARENT|SetButtonAction|instanceof|removeSWF|SetButtonImageURL|screen||setButtonDimensions|addLoadEvent|setButtonImageURL|HTTP_ERROR|SetDebugEnabled|loaded|setButtonTextPadding|RESIZE_ENCODING|setButtonText|opaque|PARAM|SetButtonDimensions|createCSS|textarea|SetButtonText'.split('|'),0,{}))
/*queue*/eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('a 3;6(k 3==="5"){3.d={};3.h.v=5(o){w 5(q){6(k o==="5"){o.n(1,q)}1.2={};1.2.7=4;1.2.f=0;1.2.e=1.c.s;1.2.p=1.c.t;1.c.s=3.d.y;1.c.t=3.d.u;1.c.m=q.m||D}}(3.h.v);3.h.x=5(r){1.2.7=4;1.E("F",[r])};3.h.J=5(){1.2.7=j;1.I();a g=1.l();G(g.A>0){1.H();g=1.l()}};3.d.u=5(8){a 9;6(k 1.2.p==="5"){9=1.2.p.n(1,8)}9=9===4?4:j;1.2.7=!9;w 9};3.d.y=5(8){a e=1.2.e;a b;6(8.z===3.B.L){1.2.f++}6(k e==="5"){b=e.n(1,8)===4?4:j}i 6(8.z===3.B.C){b=4}i{b=j}6(b){a g=1.l();6(g.A>0&&1.2.7===4){1.x()}i 6(1.2.7===4){1.K("m",[1.2.f]);1.2.f=0}i{1.2.7=4;1.2.f=0}}}}',48,48,'|this|queueSettings|SWFUpload|false|function|if|queue_cancelled_flag|file|returnValue|var|continueUpload|settings|queue|user_upload_complete_handler|queue_upload_count|stats|prototype|else|true|typeof|getStats|queue_complete_handler|call|oldInitSettings|user_upload_start_handler|userSettings|fileID|upload_complete_handler|upload_start_handler|uploadStartHandler|initSettings|return|startUpload|uploadCompleteHandler|filestatus|files_queued|FILE_STATUS|QUEUED|null|callFlash|StartUpload|while|cancelUpload|stopUpload|cancelQueue|queueEvent|COMPLETE'.split('|'),0,{}))
/*speed*/eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('g 6;a(t(6)==="9"){6.7={};6.15.1B=(9(1f){e 9(V){a(t(1f)==="9"){1f.w(3,V)}3.1i=9(W,1y){3.j[W]=(V[W]==29)?1y:V[W]};3.p={};3.c={};3.1i("1K","10");3.c.1m=3.j.1z;3.c.1j=3.j.1x;3.c.19=3.j.1w;3.c.16=3.j.1t;3.c.Y=3.j.1u;3.c.13=3.j.1v;3.c.14=3.j.1A;3.j.1z=6.7.1H;3.j.1x=6.7.1I;3.j.1w=6.7.1G;3.j.1t=6.7.1F;3.j.1u=6.7.1C;3.j.1v=6.7.1D;3.j.1A=6.7.1J;1P 3.1i}})(6.15.1B);6.7.1H=9(4){a(t 3.c.1m==="9"){4=6.7.v(4);e 3.c.1m.w(3,4)}};6.7.1I=9(4,R,O){a(t 3.c.1j==="9"){4=6.7.v(4);e 3.c.1j.w(3,4,R,O)}};6.7.1G=9(4){a(t 3.c.19==="9"){4=6.7.v(4,3.p);e 3.c.19.w(3,4)}};6.7.1F=9(4,R,O){4=6.7.v(4,3.p);6.7.Z(4,3.p);a(t 3.c.16==="9"){e 3.c.16.w(3,4,R,O)}};6.7.1C=9(4,11,1s){3.1q(4,11);4=6.7.v(4,3.p);a(t 3.c.Y==="9"){e 3.c.Y.w(3,4,11,1s)}};6.7.1D=9(4,1E){a(t 3.c.13==="9"){4=6.7.v(4,3.p);e 3.c.13.w(3,4,1E)}};6.7.1J=9(4){4=6.7.v(4,3.p);6.7.Z(4,3.p);a(t 3.c.14==="9"){e 3.c.14.w(3,4)}};6.7.v=9(4,D){g 5;a(!4){e 4}a(D){5=D[4.M]}a(5){4.C=5.C;4.G=5.G;4.A=5.A;4.I=5.I;4.J=5.J;4.L=5.L;4.1p=5.f}z{4.C=0;4.G=0;4.A=0;4.I=0;4.J=0;4.L=0;4.1p=0}e 4};6.15.1q=9(4,f){g 5=3.p[4.M];a(!5){3.p[4.M]=5={}}f=f||5.f||0;a(f<0){f=0}a(f>4.k){f=4.k}g 1r=(1k 1l()).1h();a(!5.y){5.y=(1k 1l()).1h();5.H=5.y;5.C=0;5.G=0;5.A=0;5.F=[];5.I=0;5.J=0;5.L=f/4.k;5.f=f}z a(5.y>1r){3.22("2r 2l 2k 2g")}z{g K=(1k 1l()).1h();g H=5.H;g 1a=K-H;g 1c=f-5.f;a(1c===0||1a===0){e 5}5.H=K;5.f=f;5.C=(1c*8)/(1a/1n);5.G=(5.f*8)/((K-5.y)/1n);5.F.1X(5.C);a(5.F.o>3.j.1K){5.F.27()}5.A=6.7.1Y(5.F);5.I=(4.k-5.f)*8/5.A;5.J=(K-5.y)/1n;5.L=(5.f/4.k*2s)}e 5};6.7.Z=9(4,D){2m{D[4.M]=2j;1P D[4.M]}2h(2n){}};6.7.P=9(l,r,q,1L){g i,n,Q,E;a(l===0){e"0 "+q[q.o-1]}a(1L){n=l;E=q.o>=r.o?q[r.o-1]:"";x(i=0;i<r.o;i++){a(l>=r[i]){n=(l/r[i]).1o(2);E=q.o>=i?" "+q[i]:"";2t}}e n+E}z{g 12=[];g S=l;x(i=0;i<r.o;i++){Q=r[i];E=q.o>i?" "+q[i]:"";n=S/Q;a(i<r.o-1){n=1e.2o(n)}z{n=n.1o(2)}a(n>0){S=S%Q;12.1X(n+E)}}e 12.2e(" ")}};6.7.23=9(l){g 1M=[1U,1T,1S,1],1Q=["24","2f","21","b"];e 6.7.P(l,1M,1Q,1W)};6.7.20=9(l){g 1R=[25,26,2c,1],1V=["d","h","m","s"];e 6.7.P(l,1R,1V,2d)};6.7.2b=9(l){g 1N=[1U,1T,1S,1],1O=["28","2i","2q","B"];e 6.7.P(l,1N,1O,1W)};6.7.1Z=9(l){e l.1o(2)+"%"};6.7.1Y=9(N){g u=[],k,1b=0.0,U=0.0,1d=0.0,18=0.0,1g=0.0;g i;g T=0,X=0;k=N.o;a(k>=8){x(i=0;i<k;i++){u[i]=N[i];1b+=u[i]}U=1b/k;x(i=0;i<k;i++){1d+=1e.2a((u[i]-U),2)}18=1d/k;1g=1e.2p(18);x(i=0;i<k;i++){u[i]=(u[i]-U)/1g}g 17=2.0;x(i=0;i<k;i++){a(u[i]<=17&&u[i]>=-17){X++;T+=N[i]}}}z{X=k;x(i=0;i<k;i++){T+=N[i]}}e T/X}}',62,154,'|||this|file|tracking|SWFUpload|speed||function|if||speedSettings||return|bytesUploaded|var|||settings|size|baseNumber||unit|length|fileSpeedStats|unitLabels|unitDivisors||typeof|vals|extendFile|call|for|startTime|else|movingAverageSpeed||currentSpeed|trackingList|unitLabel|movingAverageHistory|averageSpeed|lastTime|timeRemaining|timeElapsed|now|percentUploaded|id|history|message|formatUnits|unitDivisor|errorCode|remainder|mSum|mean|userSettings|settingName|mCount|user_upload_progress_handler|removeTracking||bytesComplete|formattedStrings|user_upload_success_handler|user_upload_complete_handler|prototype|user_upload_error_handler|deviationRange|variance|user_upload_start_handler|deltaTime|sum|deltaBytes|varianceTemp|Math|oldInitSettings|standardDev|getTime|ensureDefault|user_file_queue_error_handler|new|Date|user_file_queued_handler|1000|toFixed|sizeUploaded|updateTracking|tickTime|bytesTotal|upload_error_handler|upload_progress_handler|upload_success_handler|upload_start_handler|file_queue_error_handler|defaultValue|file_queued_handler|upload_complete_handler|initSettings|uploadProgressHandler|uploadSuccessHandler|serverData|uploadErrorHandler|uploadStartHandler|fileQueuedHandler|fileQueueErrorHandler|uploadCompleteHandler|moving_average_history_size|singleFractional|bpsUnits|sizeUnits|sizeUnitLabels|delete|bpsUnitLabels|timeUnits|1024|1048576|1073741824|timeUnitLabels|true|push|calculateMovingAverage|formatPercent|formatTime|Kb|debug|formatBPS|Gbps|86400|3600|shift|GB|undefined|pow|formatBytes|60|false|join|Mb|time|catch|MB|null|in|backwards|try|ex|floor|sqrt|KB|When|100|break'.split('|'),0,{}))
/**
 * 封装swfupload文件上传组件
 * author:keke
 * data:2015-05-15
 * options:是参数
 * 为什么要封装
 */
var tzUpload = {};
$.tzUpload = function(options){
	//第一步：讲我们的上传组件初始化
	//定义参数
	//第二步：封装属于自己的回调函数
	//第三步：定义自己的皮肤
	//第四步：定义文档，写上说明
	var opts = $.extend({},$.tzUpload.defaults,options);//参数的基层
	var settings = {
		flash_url : rootPath+"/js/upload/swfupload.swf",//指明文件上传的flash文件
		flash9_url : rootPath+"/js/upload/swfupload_fp9.swf",//新版的flash文件
		upload_url: opts.url,//上传的地址jsp,action,do,aps, pb
		file_size_limit : opts.size,//控制当前文件上传的大小
		file_types :opts.type,//控制文件上传的类型*.zip;*.html，*.*
		file_post_name:opts.postName,//提交给后台File对象
		post_params:opts.data,//给后台传递的参数
		file_types_description : "请选择文件",
		file_upload_limit : opts.uploadLimit,//限制文件上传的个数
		file_queue_limit : opts.queueLimit,//队列限制数量
		debug: false,//显示控制台
		// Button settings
		button_image_url: opts.img,
		button_width: 60,
		button_height: 21,
		button_placeholder_id: opts.targetId,
		button_text_left_padding: 0,
		button_text_top_padding: 0,
		button_action : (opts.single? SWFUpload.BUTTON_ACTION.SELECT_FILES : SWFUpload.BUTTON_ACTION.SELECT_FILE),
		moving_average_history_size: 40,
		// The event handler functions are defined in handlers.js
		//以下所有的事件的回调函数都定义在handler.js
		swfupload_preload_handler : opts.reload,//swfupload加载成功的回调方法
		swfupload_load_failed_handler : opts.loadFail,//swfupload插件加载失败的回调方法
		file_queued_handler :function(file){
			opts.fileQueue.call(this,file,opts);	
		},//文件加载到队列里面的回调函数--handler.js定义
		file_queue_error_handler: opts.fileQueueError,//文件加载失败的回调函数--handler.js定义
		file_dialog_complete_handler: opts.fileDialog,//点击文件上传弹出上传框触发的回调函数---handler.js定义
		upload_start_handler : opts.uploadStart,//上传开始执行的回调函数--handler.js定义
		upload_progress_handler : opts.uploadProgress,//上传过程中的回调函数--handler.js定义
		upload_success_handler : function(file,serverData){
			if(opts.callback)opts.callback(serverData);
			$.tzUpload.defaults.updateDisplay.call(this, file);
			$.tzUpload.defaults.uploadHidden(file);
			$("#"+file.id).find(".h-c3").text("上传完毕");
		},
		upload_complete_handler : opts.uploadComplete,//上传完毕的回调函数--handler.js定义
		upload_error_handler:opts.uploadError,//上传出错的回调函数--handler.js定义
		custom_settings:opts.paramsInit()
	};
	var swfu = new SWFUpload(settings);
	tzUpload = {
		start : function(fileId){
			swfu.startUpload(fileId);
		},
		cancleUpload:function(fileId){
			swfu.cancelUpload(fileId,true);
			$("#"+fileId).find(".h-c3").text("已取消");
			$("#"+fileId).parent().remove();
			var len = $("#uploadDialogBody").find(".dialog-content").length;
			if(len==0)$(".upclose").trigger("click");
		},
		cstop:function(fileId){
			$("#"+fileId).find(".h-c3").text("暂停中");
			swfu.queueSettings.queue_cancelled_flag = true;
			swfu.stopUpload();
		},
		clear:function(){
				swfu.cancelQueue();
		}
	}; 
	return swfu;
};

//默认参数设定
$.tzUpload.defaults = {
	targetId:"uploadBtn",	
	uploadBox:"",
	url:basePath+"/upload/upload",
	size:"10 MB",
	type:"*.*",
	data:{},
	postName:"doc",
	queueLimit:100,
	uploadLimit:100, 
	single:false,
	htmlbox:"",
	img:rootPath+"/js/upload/imagebtn.png",
	reload:function(){
		if (!this.support.loading) {
	 		loading("上传组件必须依赖flash文件，请为浏览器安装flash9.0版本以上的插件",4);
	 		return false;
	 	}
		$("body").append("<div id='uploadbox'></div>");
	},
	loadFail:function(){//加载插件失败回调方法
		loading("插件加载失败",4);
	},
	initEvent:function(){
		$(".tzui-up-change").click(function(){
			var mark = $(this).hasClass("upstar");
			if(mark){
				$(this).hide().next().show();	
			}else{
				$(this).hide().prev().show();
			}
		 });
		 
		 $(".upclose").click(function(){
			 var height = $("#uploadDialog").height(); 
			 $("#uploadDialog").animate({bottom:"-"+height+"px"},360,function(){
				 $(this).remove();
			 });
			 $("#uploadDialogBody").empty();
			 $.tzUpload.defaults.htmlbox ="";
		 });
		 
		 $(".upmin").click(function(){
			 var mark = $(this).hasClass("upmin");
			 if(mark){
				 var height = $("#uploadDialog").height(); 
				 $("#uploadDialog").animate({bottom:"-"+(height-42)+"px"},360);
				 $(this).removeClass("upmin").addClass("upmax").text("□");
			 }else{
				 $("#uploadDialog").animate({bottom:0},360);
				 $(this).removeClass("upmax").addClass("upmin").text("_");
			 }
		 });
		
	},
	fileQueue:function(file,opts){//上传队列的回调方法
		document.getElementById("uploadbox").innerHTML = "<div id='uploadDialog' class='upload-dialog'>"+
		"	<div class='tzui-upheader'>"+
		"		<div class='inline-mask' id='uploadHeadlineProgress'></div>"+
		"		<h4 class='dlg-h4-1 clearfix' id='uploadDialogHeadline' style='padding-left:5px;'>"+
		"			<span class='fnum'>数量/速率：<label class='rnum' id='queueNum'>0</label> / <label class='rnum' id='uploadBit'>0</label>/S</span>"+
		"			<span class='fnum'>剩余/上传：<label class='rnum' id='uploadTime'>0</label> / <label class='rnum' id='uploadOverTime'>00:00</label></span>"+
		"		</h4>"+
		"		<div style='display:none;'>"+
		"			<span id='fileError'></span>"+
		"			上传了:<span id='uploadLoaded'>0</span>"+
		"			剩余:<span id='uploadRemain'>0</span>"+
		"			总大小:<span id='uploadByte'>0</span>"+
		"			上传了:<span id='uploadCount'>0</span>个"+
		"		</div>" +
		"	</div>"+
		"	<a href='javascript:void(0);' onclick='tzUpload.clear();' class='upclose uploadicon'>X</a>"+
		"	<a href='javascript:void(0);' class='upmin uploadicon'>_</a>"+
		"	<div  id='uploadDialogBody' style='height: 375px;overflow-y:auto;overflow-x:hidden;'>"+
		"		<div class='clearfix upload-file-item' id='uploadDialogColgroup'>"+
		"			<div class='fl h-c1 ellipsis'><span class='idt-10'>标题</span></div>"+
		"			<div class='fl h-c2 size-cell'>大小</div>"+
		"			<div class='fl h-c3'>状态</div>"+
		"			<div class='fl h-c4'>操作</div>"+
		"		</div>"+
		"	</div>"+
		"</div>";
		
		$.tzUpload.defaults.htmlbox +="	<div class='dialog-content'>"+
		"			<div class='file-item' id='"+file.id+"'>"+
		"				<div class='fl h-c1 ellipsis'><span class='exticon upext_"+tm_getExt(file.name)+"'></span><span class='idt-10'>"+file.name+"</span></div>"+
		"				<div class='fl h-c2 size-cell'>"+SWFUpload.speed.formatBytes(file.size)+"</div>"+
		"				<div class='fl h-c3'>等待中</div>"+
		"				<div class='fl h-c4'>"+
		"					<a href='javascript:void(0);' onclick=tzUpload.cancleUpload('"+file.id+"') class='upicon upcancle'></a>"+
		"					<a href='javascript:void(0);' onclick=tzUpload.cstop('"+file.id+"') class='upicon tzui-up-change upstar'></a>"+
		"					<a href='javascript:void(0);' onclick=tzUpload.start('"+file.id+"') style='display:none;' class='upicon tzui-up-change upstop'></a>"+
		"				</div>"+
		"				<div class='upload_percentbox'>" +
		"					<div class='uploadPercent' id='"+file.id+"_percent'></div>"+
		"					<div id='"+file.id+"_pnumbox' class='percentnum'>"+
		"						<span id='"+file.id+"_pnum'></span>/<span id='"+file.id+"_upload'>0</span>"+
		"					</div>" +
		"				</div>"+								
		"			</div>"+
		"		</div>";
		document.getElementById("uploadDialogBody").innerHTML = $.tzUpload.defaults.htmlbox;
		this.customSettings= $.tzUpload.defaults.paramsInit();
		this.customSettings.queueNumDom.innerHTML = this.getStats().files_queued;
		$.tzUpload.defaults.initEvent();
	},
	
	fileDialog:function(file){
		this.startUpload();//开始上传
	},
	uploadStart:function(file){
 		this.customSettings.progressCount = 0;
		$("#"+file.id).find(".h-c3").text("上传中");
		$.tzUpload.defaults.updateDisplay.call(this, file);
	},
	uploadProgress:function(file, bytesLoaded, bytesTotal){//bytesTotal 是文件上传的总大小  bytesLoaded已经上传的多少
 		this.customSettings.progressCount++;
 		$.tzUpload.defaults.updateDisplay.call(this, file);
 		document.getElementById("uploadDialogBody").scrollTop = this.customSettings.progressCount * 40 ; 
	},
	uploadComplete:function(file){
		this.customSettings.queueNumDom.innerHTML = this.getStats().files_queued;
		 //显示上传的多少个文件了
		this.customSettings.uploadCountDom.innerHTML = this.getStats().successful_uploads;
		//显示错误信息,显示错误信息的个数
		//this.customSettings.fileErrorDom.innerHTML = this.getStats().upload_errors;
	},
	updateDisplay:function(file) {
		 //上传了多少
		 $("#"+file.id+"_upload").html(SWFUpload.speed.formatBytes(file.sizeUploaded));
		 //上传文件的总大小
		 this.customSettings.uploadByteDom.innerHTML = SWFUpload.speed.formatBytes(file.size);
		 //还剩余多少没有上传
		 this.customSettings.uploadRemainDom.innerHTML = SWFUpload.speed.formatBytes(file.size-file.sizeUploaded);
		 //控制进度条的走向
	 	 $("#"+file.id+"_percent").width(SWFUpload.speed.formatPercent(file.percentUploaded));
	 	 //上传百度比的数字的展示和走动
	 	 $("#"+file.id+"_pnumbox").css("left",SWFUpload.speed.formatPercent(file.percentUploaded-25));
	 	 $("#"+file.id+"_pnum").html(SWFUpload.speed.formatPercent(file.percentUploaded));
	 	 //当前速度
	 	 this.customSettings.uploadBitDom.innerHTML = SWFUpload.speed.formatBPS(file.averageSpeed);
	 	 //剩下时间
	 	 this.customSettings.uploadTimeDom.innerHTML = SWFUpload.speed.formatTime(file.timeRemaining);
	 	 //移动平均线速度（上传速度）
	 	 //this.customSettings.tdMovingAverageSpeed.innerHTML = SWFUpload.speed.formatBPS(file.movingAverageSpeed);
	 	 //时间过去了(上传了多久了)
	 	 this.customSettings.uploadOverTimeDom.innerHTML = SWFUpload.speed.formatTime(file.timeElapsed);
	 },
	 fileQueueError:function(file, errorCode, message) {
	 	try {
	 		$.tzUpload.defaults.uploadHidden(file);
	 		var fileError = "fileError";
	 		if (errorCode === SWFUpload.QUEUE_ERROR.QUEUE_LIMIT_EXCEEDED) {
	 			$.tzUpload.defaults.uploadShowError(fileError,"队列已满,请稍后上传...");
	 			return;
	 		}
	 		switch (errorCode) {
	 		case SWFUpload.QUEUE_ERROR.FILE_EXCEEDS_SIZE_LIMIT:
	 			$.tzUpload.defaults.uploadShowError(fileError,file.name+"文件太大了!(不的超过"+this.settings.file_size_limit+")."+SWFUpload.speed.formatBytes(file.size));
	 			this.debug("Error Code: File too big, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		case SWFUpload.QUEUE_ERROR.ZERO_BYTE_FILE:
	 			$.tzUpload.defaults.uploadShowError(fileError,"您上传的文件是空的...");
	 			this.debug("Error Code: Zero byte file, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		case SWFUpload.QUEUE_ERROR.INVALID_FILETYPE:
	 			$.tzUpload.defaults.uploadShowError(fileError,"无效文件类型");
	 			this.debug("Error Code: Invalid File Type, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		case SWFUpload.QUEUE_ERROR.QUEUE_LIMIT_EXCEEDED:
	 			$.tzUpload.defaults.uploadShowError(fileError,"您选择文件超过限制["+this.settings.file_upload_limit+"个]...");
	 			break;
	 		default:
	 			if (file !== null) {
	 				$.tzUpload.defaults.uploadShowError(fileError,"出现错误");
	 			}
	 			this.debug("Error Code: " + errorCode + ", File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		}
	 	} catch (ex) {
	         this.debug(ex);
	     }
	},
	uploadError:function(file, errorCode, message) {
	 	try {
	 		var fileError = "fileError";
	 		switch (errorCode) {
	 		case SWFUpload.UPLOAD_ERROR.HTTP_ERROR:
	 			$.tzUpload.defaults.uploadShowError(fileError,"上传出现错误: " + message);
	 			this.debug("Error Code: HTTP Error, File name: " + file.name + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.MISSING_UPLOAD_URL:
	 			$.tzUpload.defaults.uploadShowError(fileError,"配置有问题，上传地址有误");
	 			this.debug("Error Code: No backend file, File name: " + file.name + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.UPLOAD_FAILED:
	 			$.tzUpload.defaults.uploadShowError(fileError,"上传失败...");
	 			this.debug("Error Code: Upload Failed, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.IO_ERROR:
	 			$.tzUpload.defaults.uploadShowError(fileError,"上传初始错误");
	 			this.debug("Error Code: IO Error, File name: " + file.name + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.SECURITY_ERROR:
	 			$.tzUpload.defaults.uploadShowError(fileError,"出现安全错误");
	 			this.debug("Error Code: Security Error, File name: " + file.name + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.UPLOAD_LIMIT_EXCEEDED:
	 			$.tzUpload.defaults.uploadShowError(fileError,"超过上传的限制.");
	 			this.debug("Error Code: Upload Limit Exceeded, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.SPECIFIED_FILE_ID_NOT_FOUND:
	 			$.tzUpload.defaults.uploadShowError(fileError,"文件没有找到.");
	 			this.debug("Error Code: The file was not found, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.FILE_VALIDATION_FAILED:
	 			$.tzUpload.defaults.uploadShowError(fileError,"验证失败，上传被挂起.");
	 			this.debug("Error Code: File Validation Failed, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.FILE_CANCELLED:
	 			if (this.getStats().files_queued === 0) {
	 				document.getElementById(this.customSettings.cancelButtonId).disabled = true;
	 			}
	 			$.tzUpload.defaults.uploadShowError(fileError,"取消上传");
	 			progress.setCancelled();
	 			break;
	 		case SWFUpload.UPLOAD_ERROR.UPLOAD_STOPPED:
	 			$.tzUpload.defaults.uploadShowError(fileError,"暂停上传");
	 			break;
	 		default:
	 			this.debug("Error Code: " + errorCode + ", File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
	 			break;
	 		}
	 	} catch (ex) {
	         this.debug(ex);
	     }
	 },
	 paramsInit:function(){
		 return {
			queueNumDom:document.getElementById("queueNum"),
			uploadFileNameDom:document.getElementById("uploadFileName"),
			uploadByteDom:document.getElementById("uploadByte"),
			uploadLoadedDom:document.getElementById("uploadLoaded"),
			uploadRemainDom:document.getElementById("uploadRemain"),
			uploadLoadNumDom:document.getElementById("uploadLoadNum"),
			uploadPercentDom:document.getElementById("uploadPercent"),
			uploadCountDom:document.getElementById("uploadCount"),
			fileErrorDom:document.getElementById("fileError"),
			uploadBitDom:document.getElementById("uploadBit"),
			uploadTimeDom:document.getElementById("uploadTime"),
			uploadOverTimeDom:document.getElementById("uploadOverTime")
		};
	 },
	 uploadHidden:function(file){
		 $("#"+file.id).parent().fadeOut(2000,function(){
			$(this).remove();
			var len = $("#uploadDialogBody").find(".dialog-content").length;
			if(len==0)$(".upclose").trigger("click");
		 });
	 },
	 uploadShowError:function(id,message){
		 $("#"+id).show().html(message).stop(true).fadeOut(2000);
	 }
};
